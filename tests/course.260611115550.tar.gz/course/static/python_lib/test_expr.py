#!/usr/bin/env python2
"""
Development testing for python graders
"""
from mitxgraders import *
import numpy as np
grader = FormulaGrader(
    variables=['alpha', 'beta', 'gamma', 'a_randomphase'],
    sample_from={
        'alpha': ComplexSector(modulus=[0, 0.6], argument=[-np.pi, np.pi]),
        'beta': ComplexSector(modulus=[0, 0.6], argument=[-np.pi, np.pi]),
        'a_randomphase': [0, 6.283],
#        'gamma': DependentSampler(depends=['alpha', 'beta', 'a_randomphase'], formula='exp(i*a_randomphase)*sqrt(1-abs(alpha)^2-abs(beta)^2)')
        'gamma': DependentSampler(depends=['alpha', 'beta', 'a_randomphase'], formula='exp(i)')
    }
)

print(grader("1", "1"))
