"""
defaults.py

This plug-in is used to set course-wide defaults.
"""
from __future__ import print_function, division, absolute_import, unicode_literals

# Here are all of the graders that you can specify defaults for
from mitxgraders.stringgrader import StringGrader
from mitxgraders.baseclasses import AbstractGrader, ItemGrader
from mitxgraders.listgrader import ListGrader, SingleListGrader
from mitxgraders.formulagrader.integralgrader import IntegralGrader
from mitxgraders.formulagrader.formulagrader import FormulaGrader, NumericalGrader
from mitxgraders.formulagrader.matrixgrader import MatrixGrader

# These will be needed to set attempt-based credit course-wide
from mitxgraders.attemptcredit import LinearCredit, GeometricCredit, ReciprocalCredit

# Turn on attempt-based partial credit by default and modify related settings
# AbstractGrader.register_defaults({
#     'attempt_based_credit': ReciprocalCredit(),
#     'attempt_based_credit_msg': True
# })
# Note that if you do this, you will need to either pass cfn_extra_args="attempt" in every
# customresponse tag or explicitly disable attempt-based credit.
